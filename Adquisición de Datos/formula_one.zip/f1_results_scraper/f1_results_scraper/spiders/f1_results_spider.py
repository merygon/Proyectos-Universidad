import scrapy
from scrapy.crawler import CrawlerProcess
import pandas as pd
import os

"""
Elaborado por Sergio Jiménez, María González, Carlos Martínez y Iván Rodríguez
"""


class F1ResultsSpider(scrapy.Spider):
    """
    Spider el cual obtiene los resultados de las carreras de F1 desde 2012 hasta 2023

    """

    # Nombre del Spider
    name = "f1_results"

    # URLS de las páginas de wikipedia necesarias
    start_urls = [
        f"https://en.wikipedia.org/wiki/{year}_Formula_One_World_Championship"
        for year in range(2012, 2024)
    ]

    ## Métodos del spider para obtener los datos necesarios de cada página web
    def parse(self, response):
        """
        Esta función se encarga de buscar la tabla con resultados de las carreras de cada año.
        Una vez encontrada, obtiene la columna con los 'Report',
        la cual nos lleva a una nueva página web que tiene información sobre la carrera en concreto.
        """
        # Busca y obtiene la tabla que queremos
        target_table = None
        for table in response.xpath('//table[@class="wikitable sortable"]'):
            header_text = table.xpath(".//th//text()").extract()
            if "Grand Prix" in header_text and "Report" in header_text:
                target_table = table

        if target_table:
            numero_carrera = 0
            # Recorre las filas de la tabla (excluyendo la primera fila de encabezados)
            for row in target_table.xpath(".//tr[position()>1]"):
                # Extrae el enlace en la columna "Report" (columna 6)
                report_link = row.xpath(".//td[6]/a/@href").extract_first()
                if report_link:
                    numero_carrera += 1
                    yield scrapy.Request(
                        response.urljoin(report_link),
                        callback=self.parse_report,
                        meta={"numero_carrera": numero_carrera},
                    )
        else:
            self.log("No se encontró la tabla objetivo.")

    def parse_report(self, response):
        """
        Esta función, tiene como objetivo encontrar la tabla con la información que queremos,
        busca entre las tablas de la página y encuentra la que contiene los resultados de la carrera.
        """

        # Obtiene el año, el nombre del prix y el número de carrera de la temporada
        report_title = response.xpath("//title/text()").extract_first()
        numero_carrera = response.meta["numero_carrera"]
        year = report_title.split(" ", 1)[0]
        if year == "70th":
            year = "2020"
        prix = f"#{numero_carrera} " + report_title.lstrip(f"{year} ").rstrip(
            " - Wikipedia"
        )

        # Cada carrera se almacena en un fichero con el año en la que se realizó
        os.makedirs(year, exist_ok=True)

        # Se almacena en formato csv
        path = os.path.join(year, prix) + ".csv"
        self.log(f"Página del informe: {report_title}")

        # Busca en todas las tablas posibles que sean 'wikitable' o 'wikitable sortable'
        target_tables = response.xpath(
            '//table[contains(@class, "wikitable") or contains(@class, "wikitable sortable")]'
        )

        # Itera sobre las tablas encontradas hasta que encuentra la que queremos
        final_table = None
        for index, target_table in enumerate(target_tables, start=1):
            header_row = target_table.xpath(".//tr[1]").extract()[0]
            if (
                "Grid" in header_row or "Start" in header_row
            ) and "Points" in header_row:
                final_table = target_table

        # Obtiene la información de la tabla y la guarda
        if final_table is not None:
            rows = []
            for row in final_table.xpath(".//tr[position()>1]"):
                data = []
                for cell in row.xpath(".//td|th"):
                    cell_text = " ".join(cell.xpath(".//text()").extract()).strip()
                    data.append(cell_text)
                rows.append(data)

            # Crea un DataFrame con los datos y lo convierte en un csv
            df = pd.DataFrame(
                rows,
                columns=[
                    "Pos",
                    "No.",
                    "Driver",
                    "Constructor",
                    "Laps",
                    "Time/Retired",
                    "Grid",
                    "Points",
                ],
            )
            df.to_csv(path)


## MAIN
def create_scrapy_csv():
    # Inicaliza el spider
    process = CrawlerProcess()

    process.crawl(F1ResultsSpider)
    process.start()
