from gpiozero import MCP3008

sensor = MCP3008(channel=0)
print(
    f"La salida del sensor es: {sensor.voltage}, {sensor.value} # porcentaje de lo que sale respecto a lo que sale."
)
# a mayor voltaje mayor humedad
