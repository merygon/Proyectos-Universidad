from gpiozero import MotionSensor, PWMLED
from time import sleep

sensor = MotionSensor(14)
leds = [PWMLED(i) for i in range(20, 28)]


def cambiar_leds():
    for led in leds:
        led.toggle()


sensor.when_motion = cambiar_leds
sensor.when_no_motion = cambiar_leds

while True:
    sleep(1)
