from gpiozero import AngularServo, Button
from gpiozero.pins.pigpio import PiGPIOFactory
from time import sleep


def abrir_puerta():
    global servo
    angulo = 45
    print("Puerta abierta.")
    servo.angle = angulo
    print(servo.angle)
    sleep(2)
    servo.min()
    print("Puerta cerrada.")


if __name__ == "__main__":
    factory = PiGPIOFactory()
    servo = AngularServo(
        22,
        min_angle=0,
        max_angle=180,
        min_pulse_width=0.0005,
        max_pulse_width=0.0025,
        pin_factory=factory,
    )
    servo.min()
    boton_abrir = Button(16)
    boton_abrir.when_pressed = abrir_puerta
    # boton_abrir.when_released = cerrar_puerta
    while True:
        sleep(1)
    # servo.min()
    # sleep(2)
    # servo.max()
