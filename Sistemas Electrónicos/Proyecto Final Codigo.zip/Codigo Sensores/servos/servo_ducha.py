from gpiozero import AngularServo, Button
from gpiozero.pins.pigpio import PiGPIOFactory
from time import sleep


def abrir_ducha():
    global servo
    angulo = 90
    print("Ducha abierta.")
    servo.angle = angulo
    print(servo.angle)
    sleep(2)
    servo.min()
    print("Ducha cerrada.")


if __name__ == "__main__":
    factory = PiGPIOFactory()
    servo = AngularServo(
        15,
        min_angle=0,
        max_angle=180,
        min_pulse_width=0.0005,
        max_pulse_width=0.0025,
        pin_factory=factory,
    )
    servo.min()
    boton_abrir = Button(17)
    boton_abrir.when_pressed = abrir_ducha
    while True:
        sleep(1)
