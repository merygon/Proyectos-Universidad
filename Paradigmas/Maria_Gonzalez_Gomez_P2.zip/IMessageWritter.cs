﻿namespace Practice1
{
    interface IMessageWritter
    {
        string WriteMessage(string customMessage);
    }
}