import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from tkinter import simpledialog
import random
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


class Agente:
    def __init__(self, juego):
        """
        Definimos los atributos de la clase agente
        """
        self.juego = juego
        self.riesgo = 0.2
        self.dimension = 6
        self.num_casillas = self.dimension**2
        self.prior = 1 / self.num_casillas
        self.prob_inicio = [
            1 / (self.num_casillas - 1) for _ in range(self.num_casillas)
        ]

    def evaluar_percepto(self, nueva_posicion: tuple, percept: str):
        """
        Se evalua el tipo de percepto dado y se avisa al jugador de lo que este implica.
        """
        if percept == "olor":
            messagebox.showinfo(
                "Accion",
                "¡Hay una peste cerca, cuidado el monstruo puede hayarse en las habitaciones adyacentes!",
            )
            self.tomar_decision(nueva_posicion, percept)

        elif percept == "cables":
            messagebox.showinfo(
                "Accion",
                "¡Hay cables en el suelo, cuidado la trampa de dardos venenosos puede hayarse en las habitaciones adyacentes!",
            )
            self.tomar_decision(nueva_posicion, percept)

        elif percept == "suelo crujir":
            messagebox.showinfo(
                "Accion",
                "¡El suelo esta crujiendo, cuidado la trampa de pinchos puede hayarse en las habitaciones adyacentes!",
            )
            self.tomar_decision(nueva_posicion, percept)

        elif percept == "olor queroseno":
            messagebox.showinfo(
                "Accion",
                "¡Hay un olor queroseno cerca, cuidado la trampa de fuego puede hayarse en las habitaciones adyacentes!",
            )
            self.tomar_decision(nueva_posicion, percept)

        elif percept == "luz brillante":
            messagebox.showinfo(
                "Accion",
                "Se percibe una luz brillante cerca, la salida debe estar en una de las habitaciones contiguas.",
            )

    def tomar_decision(self, nueva_posicion: tuple, percept: str):
        """
        Dada la posición actual del jugador, en caso de que halla recibido un percepto negativo, se le indican sus posibles movimientos.
        """
        self.actualiza_probabilidades(nueva_posicion, percept)

    def actualiza_probabilidades(self, posicion, percept):
        adyacentes = self.juego.calcular_adyacentes(posicion)
        verosimilitud = self.calcular_verosimilitud(posicion)
        dic_posterior = {}

        if percept == "olor":
            dic_posterior = self.normalizar_posteriors(
                adyacentes, self.juego.trampas_monstruo.copy()
            )
        elif percept == "cables":
            dic_posterior = self.normalizar_posteriors(
                adyacentes, self.juego.trampas_dardos.copy()
            )
        elif percept == "suelo crujir":
            dic_posterior = self.normalizar_posteriors(
                adyacentes, self.juego.trampas_pinchos.copy()
            )
        elif percept == "olor queroseno":
            dic_posterior = self.normalizar_posteriors(
                adyacentes, self.juego.trampas_fuego.copy()
            )
        else:
            probabilidad_total = 0
            for adyacente in adyacentes:
                if 0 <= adyacente[0] <= 5 and 0 <= adyacente[1] <= 5:
                    posterior = (verosimilitud * self.prior) / (
                        (self.num_casillas - len(self.juego.posiciones_seguras))
                        / self.num_casillas
                    )
                    dic_posterior[adyacente] = posterior
                    probabilidad_total += posterior

                if probabilidad_total > 1:
                    dic_posterior = {
                        k: v / probabilidad_total for k, v in dic_posterior.items()
                    }
        if percept != "otros":
            self.generar_mapas(dic_posterior, percept)

    def normalizar_posteriors(self, adyacentes: list, trampas: set):
        """
        Devuelve un diccionario con las posiciones y su determinada probabilidad de riesgo
        """
        dic_posterior = {}
        probabilidad_total = 0
        casillas_adyacentes_peligrosas = 0

        for posicion in adyacentes:
            if posicion in trampas:
                casillas_adyacentes_peligrosas += 1

        for posicion in adyacentes:
            if posicion in trampas:
                posterior = 1 / casillas_adyacentes_peligrosas
                dic_posterior[posicion] = posterior
                probabilidad_total += posterior

            if probabilidad_total > 1:
                dic_posterior = {
                    k: v / probabilidad_total for k, v in dic_posterior.items()
                }

        return dic_posterior

    def realizar_conclusiones(self, num_trampas: int, percept: str):
        """
        Se encarga de ir evaluando el número de posiciones en los sets de trampas, cuando solo quede una posible, se hará saber
        pasando las variables de encontrado a true y se dejará de recibir el percepto al pasar por una casilla adyacente a la trampa
        ya que estará marcada con su correspondiente símbolo marcado de un signo de exclamación.
        """
        if num_trampas == 1 and percept == "olor":
            self.juego.monstruo_encontrada = True
            lista_posiciones = list(self.juego.trampas_monstruo.copy())
            posicion_monstruo = lista_posiciones[0]
            self.juego.marcar_casilla(posicion_monstruo, "M!")

        if num_trampas == 1 and percept == "olor queroseno":
            self.juego.trampa_fuego_encontrada = True
            lista_posiciones = list(self.juego.trampas_fuego.copy())
            posicion_trampa_fuego = lista_posiciones[0]
            self.juego.marcar_casilla(posicion_trampa_fuego, "F!")

        if num_trampas == 1 and percept == "suelo crujir":
            self.juego.trampa_pinchos_encontrada = True
            lista_posiciones = list(self.juego.trampas_pinchos.copy())
            posicion_trampa_pinchos = lista_posiciones[0]
            self.juego.marcar_casilla(posicion_trampa_pinchos, "P!")

        if num_trampas == 1 and percept == "cables":
            self.juego.trampa_dardos_encontrada = True
            lista_posiciones = list(self.juego.trampas_dardos.copy())
            posicion_trampa_dardos = lista_posiciones[0]
            self.juego.marcar_casilla(posicion_trampa_dardos, "D!")

    def calcular_verosimilitud(self, posicion: tuple):
        """
        Calcula la verosimilitud de recibir el percepto si estás en esa celda
        """
        adyacentes = self.juego.calcular_adyacentes(posicion)
        trampas = [
            self.juego.trampa_fuego,
            self.juego.trampa_pinchos,
            self.juego.trampa_dardos_venenosos,
            self.juego.monstruo,
        ]

        for trampa in trampas:
            if trampa in adyacentes:
                return 1
            else:
                return 0

    def generar_mapas(self, dic_posteriors: dict, percept: str):
        """
        Genera un heatmap que muestra la probabilidad de encontrar trampas en las casillas adyacentes a la posición actual
        """

        if percept == "olor":
            trampa = "monstruo"
        elif percept == "cables":
            trampa = "dardos venenosos"
        elif percept == "suelo crujir":
            trampa = "pinchos"
        elif percept == "olor queroseno":
            trampa = "fuego"

        mapa_probabilidad = [[0] * self.dimension for _ in range(self.dimension)]

        for i in range(self.dimension):
            for j in range(self.dimension):
                if (i, j) in dic_posteriors.keys():
                    mapa_probabilidad[i][j] = dic_posteriors[(i, j)]
                else:
                    mapa_probabilidad[i][j] = 0

        plt.figure(figsize=(10, 5))
        sns.heatmap(
            mapa_probabilidad, annot=True, cmap="YlOrRd", linewidths=0.5, vmin=0, vmax=1
        )
        plt.title(f"Mapa de Probabilidad de la trampa de {trampa}")
        plt.xlabel("Columna")
        plt.ylabel("Fila")
        plt.show()


class Juego:
    def __init__(self):
        """
        Definimos los atributos de la clase Juego
        """
        self.ventana = tk.Tk()
        self.ventana.title("Encontrar al coronel Kurt")
        self.ventana.geometry("400x400")

        self.tablero = self.inicializar_tablero()
        self.posicion_cw = (0, 0)
        self.monstruo_derrotado = False
        self.monstruo_encontrado = False
        self.coronel_kurt_encontrado = False
        self.trampa_dardos_encontrada = False
        self.trampa_fuego_encontrada = False
        self.trampa_pinchos_encontrada = False
        self.trampas_monstruo = set()
        self.trampas_fuego = set()
        self.trampas_pinchos = set()
        self.trampas_dardos = set()
        self.posiciones_seguras = set()
        self.posiciones_peligrosas = set()

        self.inicializar_elementos()

        self.cuadros = []
        for i in range(6):
            fila = []
            for j in range(6):
                celda = tk.Label(
                    self.ventana, text="", width=10, height=5, relief="sunken"
                )
                celda.grid(row=i, column=j)
                fila.append(celda)
            self.cuadros.append(fila)

        self.mostrar_tablero()

        self.ventana.bind("<Up>", self.mover_arriba)
        self.ventana.bind("<Down>", self.mover_abajo)
        self.ventana.bind("<Right>", self.mover_derecha)
        self.ventana.bind("<Left>", self.mover_izquierda)

        self.ventana.mainloop()

    def inicializar_tablero(self):
        """
        Creamos el tablero inicialmente vacio y de tamaño 6x6
        """
        return [[" " for _ in range(6)] for _ in range(6)]

    def colocar_elementos(self, elemento):
        """
        Definimos posiciones aleatorias para los elementos en el tablero
        """
        fila, columna = random.randint(0, 5), random.randint(0, 5)
        posiciones = [
            self.monstruo,
            self.trampa_dardos_venenosos,
            self.trampa_fuego,
            self.trampa_pinchos,
            self.posicion_cw,
        ]
        while self.tablero[fila][columna] != " " or (fila, columna) in posiciones:
            fila, columna = random.randint(0, 5), random.randint(0, 5)
        self.tablero[fila][columna] = elemento
        return fila, columna

    def inicializar_elementos(self):
        """
        Colocamos los elementos en sus posiciones asignadas
        """
        self.posicion_cw = (0, 0)

        self.monstruo = (random.randint(0, 5), random.randint(0, 5))
        while self.monstruo == self.posicion_cw:
            self.monstruo = (random.randint(0, 5), random.randint(0, 5))

        self.trampa_fuego = (random.randint(0, 5), random.randint(0, 5))
        while self.trampa_fuego == self.posicion_cw:
            self.trampa_fuego = (random.randint(0, 5), random.randint(0, 5))

        self.trampa_pinchos = (random.randint(0, 5), random.randint(0, 5))
        while self.trampa_pinchos == self.posicion_cw:
            self.trampa_pinchos = (random.randint(0, 5), random.randint(0, 5))

        self.trampa_dardos_venenosos = (random.randint(0, 5), random.randint(0, 5))
        while self.trampa_dardos_venenosos == self.posicion_cw:
            self.trampa_dardos_venenosos = (random.randint(0, 5), random.randint(0, 5))

        self.salida = self.colocar_elementos("S")

        self.ck = (random.randint(0, 5), random.randint(0, 5))
        posiciones = [
            self.monstruo,
            self.trampa_dardos_venenosos,
            self.trampa_fuego,
            self.trampa_pinchos,
            self.salida,
            self.posicion_cw,
        ]
        while self.ck in posiciones:
            self.ck = (random.randint(0, 5), random.randint(0, 5))

    def mostrar_tablero(self):
        """
        Mostramos el tablero en la terminal de python
        """
        colors = {
            " ": "white",
            "S": "green",
        }  # asignación de colores a los elementos que aparecen en el tablero

        for i in range(6):
            for j in range(6):
                elemento = self.tablero[i][j]
                color = colors.get(elemento, "white")
                self.cuadros[i][j].config(bg=color)

    def mostrar_interfaz(self):
        """
        Mostramos la interfaz del tablero
        """

        for i in range(6):
            for j in range(6):
                label = tk.Label(
                    self.ventana,
                    text=self.tablero[i][j],
                    width=5,
                    height=3,
                    relief="solid",
                )
                label.grid(row=i, column=j)

        cw_label = tk.Label(self.ventana, text="CW", font=("Arial", 12, "bold"))
        cw_label.grid(row=self.posicion_cw[0], column=self.posicion_cw[1])

        self.mostrar_tabla()

    def mostrar_tabla(self):
        """
        Mostramos una tabla adjunta a la interfaz donde se muestran las coordenadas de las posiciones peligrosas, es decir,
        donde pueden encontrarse el monstruo y el precipicio, y las posiciones seguras por donde el Coronel W puede desplazarse
        sin miedo a ser derrotado.
        """
        frame = ttk.Frame(self.ventana)
        frame.grid(row=0, column=6, rowspan=3, columnspan=3)

        tree = ttk.Treeview(
            frame,
            columns=("Posiciones Seguras", "Posiciones Peligrosas"),
            show="headings",
            height=5,
        )
        tree.heading("Posiciones Seguras", text="Posiciones Seguras")
        tree.heading("Posiciones Peligrosas", text="Posiciones Peligrosas")

        for posicion in self.posiciones_seguras:
            tree.insert("", "end", values=(posicion, ""))

        for posicion in self.posiciones_peligrosas:
            tree.insert("", "end", values=("", posicion))

        tree.pack()

    def mover_arriba(self, event):
        """
        Definimos la acción de moverse arriba que se correspondera con la flecha del ordenador que apunta arriba
        """
        nueva_fila = max(0, self.posicion_cw[0] - 1)
        self.verificar_percept((nueva_fila, self.posicion_cw[1]))
        self.realizar_accion(nueva_fila, self.posicion_cw[1])
        self.actualizar_posicion((nueva_fila, self.posicion_cw[1]))

    def mover_abajo(self, event):
        """
        Definimos la acción de moverse abajo que se correspondera con la flecha del ordenador que apunta abajo
        """
        nueva_fila = min(5, self.posicion_cw[0] + 1)
        self.verificar_percept((nueva_fila, self.posicion_cw[1]))
        self.realizar_accion(nueva_fila, self.posicion_cw[1])
        self.actualizar_posicion((nueva_fila, self.posicion_cw[1]))

    def mover_derecha(self, event):
        """
        Definimos la acción de desplazarse a la derecha que se correspondera con la flecha del ordenador que apunta a la derecha
        """
        nueva_columna = min(5, self.posicion_cw[1] + 1)
        self.verificar_percept((self.posicion_cw[0], nueva_columna))
        self.realizar_accion(self.posicion_cw[0], nueva_columna)
        self.actualizar_posicion((self.posicion_cw[0], nueva_columna))

    def mover_izquierda(self, event):
        """
        Definimos la acción de desplazarse a la izquierda que se correspondera con la flecha del ordenador que apunta a la izquierda
        """
        nueva_columna = max(0, self.posicion_cw[1] - 1)
        self.verificar_percept((self.posicion_cw[0], nueva_columna))
        self.realizar_accion(self.posicion_cw[0], nueva_columna)
        self.actualizar_posicion((self.posicion_cw[0], nueva_columna))

    def verificar_percept(self, nueva_posicion: tuple):
        """
        Estudiamos las posiciones adyacentes a donde está CW, si en alguna de estas está el monstruo o alguna de las otras trampas,
        se recibirá dicho precepto y se añadirán las posiciones adjuntas a la posición actual al conjunto de peligrosas,
        en caso de no percibir nada, se añadirán al conjunto de seguras. La posición acutal es añadida al conjunto de seguras.
        """
        self.posiciones_seguras.add(nueva_posicion)

        adyacentes = [
            (nueva_posicion[0] - 1, nueva_posicion[1]),
            (nueva_posicion[0] + 1, nueva_posicion[1]),
            (nueva_posicion[0], nueva_posicion[1] - 1),
            (nueva_posicion[0], nueva_posicion[1] + 1),
        ]  # calculo de las posiciones adyacentes a la actual.

        agente = Agente(self)  # instancia de un agente

        for posicion in adyacentes:
            fila, columna = posicion

            if (
                0 <= fila <= 5 and 0 <= columna <= 5
            ):  # unicamente consideramos adyacentes admisibles las que se encuentren dentro de los límites del tablero
                elemento = self.tablero[fila][columna]

                if (
                    elemento != "S"
                    and posicion != self.ck
                    and posicion not in self.posiciones_seguras
                ):
                    if (
                        posicion == self.monstruo and self.monstruo_encontrado == False
                    ):  # si es el monstruo y no ha sido ya derrotado
                        percept = "olor"
                        for adyacente in adyacentes:
                            if (
                                adyacente not in self.posiciones_seguras
                                and adyacente not in self.trampas_fuego
                                and adyacente not in self.trampas_pinchos
                                and adyacente not in self.trampas_dardos
                                and adyacente != self.salida
                                and 0 <= adyacente[0] <= 5
                                and 0 <= adyacente[1] <= 5
                            ):
                                self.posiciones_peligrosas.add(adyacente)
                                self.trampas_monstruo.add(adyacente)
                                self.marcar_casilla(adyacente, "M?")
                                self.marcar_casilla(nueva_posicion, "eM")

                        for pos in self.trampas_monstruo.copy():
                            if pos not in adyacentes and pos != self.monstruo:
                                self.marcar_casilla(pos, "")
                                self.trampas_monstruo.remove(pos)
                                self.posiciones_peligrosas.remove(pos)

                        agente.evaluar_percepto(nueva_posicion, percept)

                        agente.realizar_conclusiones(
                            len(self.trampas_monstruo.copy()), percept
                        )

                    elif (
                        posicion == self.trampa_dardos_venenosos
                        and self.trampa_dardos_encontrada == False
                    ):
                        percept = "cables"
                        for adyacente in adyacentes:
                            if (
                                adyacente not in self.posiciones_seguras
                                and adyacente not in self.trampas_fuego
                                and adyacente not in self.trampas_monstruo
                                and adyacente not in self.trampas_dardos
                                and adyacente != self.salida
                                and 0 <= adyacente[0] <= 5
                                and 0 <= adyacente[1] <= 5
                            ):
                                self.posiciones_peligrosas.add(adyacente)
                                self.trampas_dardos.add(adyacente)
                                self.marcar_casilla(adyacente, "D?")
                                self.marcar_casilla(nueva_posicion, "eD")

                        for pos in self.trampas_dardos.copy():
                            if (
                                pos not in adyacentes
                                and pos != self.trampa_dardos_venenosos
                            ):
                                self.marcar_casilla(pos, "")
                                self.trampas_dardos.remove(pos)
                                self.posiciones_peligrosas.remove(pos)
                                self.posiciones_seguras.add(pos)

                        agente.evaluar_percepto(nueva_posicion, percept)

                        agente.realizar_conclusiones(
                            len(self.trampas_dardos.copy()), percept
                        )

                    elif (
                        posicion == self.trampa_fuego
                        and self.trampa_fuego_encontrada == False
                    ):
                        percept = "olor queroseno"
                        for adyacente in adyacentes:
                            if (
                                adyacente not in self.posiciones_seguras
                                and adyacente not in self.trampas_pinchos
                                and adyacente not in self.trampas_monstruo
                                and adyacente not in self.trampas_dardos
                                and adyacente != self.salida
                                and 0 <= adyacente[0] <= 5
                                and 0 <= adyacente[1] <= 5
                            ):
                                self.posiciones_peligrosas.add(adyacente)
                                self.trampas_fuego.add(adyacente)
                                self.marcar_casilla(adyacente, "F?")
                                self.marcar_casilla(nueva_posicion, "eF")

                        for pos in self.trampas_fuego.copy():
                            if pos not in adyacentes and pos != self.trampa_fuego:
                                self.marcar_casilla(pos, "")
                                self.trampas_fuego.remove(pos)
                                self.posiciones_peligrosas.remove(pos)
                                self.posiciones_seguras.add(pos)

                        agente.evaluar_percepto(nueva_posicion, percept)

                        agente.realizar_conclusiones(
                            len(self.trampas_fuego.copy()), percept
                        )

                    elif (
                        posicion == self.trampa_pinchos
                        and self.trampa_pinchos_encontrada == False
                    ):
                        percept = "suelo crujir"
                        for adyacente in adyacentes:
                            if (
                                adyacente not in self.posiciones_seguras
                                and adyacente not in self.trampas_fuego
                                and adyacente not in self.trampas_monstruo
                                and adyacente not in self.trampas_pinchos
                                and adyacente != self.salida
                                and 0 <= adyacente[0] <= 5
                                and 0 <= adyacente[1] <= 5
                            ):
                                self.posiciones_peligrosas.add(adyacente)
                                self.trampas_pinchos.add(adyacente)
                                self.marcar_casilla(adyacente, "P?")
                                self.marcar_casilla(nueva_posicion, "eP")

                        for pos in self.trampas_pinchos.copy():
                            if pos not in adyacentes and pos != self.trampa_pinchos:
                                self.marcar_casilla(pos, "")
                                self.trampas_pinchos.remove(pos)
                                self.posiciones_peligrosas.remove(pos)
                                self.posiciones_seguras.add(pos)

                        agente.evaluar_percepto(nueva_posicion, percept)

                        agente.realizar_conclusiones(
                            len(self.trampas_pinchos.copy()), percept
                        )

                    else:
                        if (
                            posicion != self.monstruo
                            and posicion != self.trampa_dardos_venenosos
                            and posicion != self.trampa_fuego
                            and posicion != self.trampa_pinchos
                        ):
                            self.posiciones_seguras.add(posicion)

                if elemento == "S":
                    percept = "luz brillante"
                    agente.evaluar_percepto(posicion, percept)
                    self.posiciones_seguras.add(posicion)

    def actualizar_posicion(self, nueva_posicion: tuple):
        """
        Actualizamos la posición del Coronel W según se desplaza por el mapa
        """
        self.posicion_cw = nueva_posicion
        self.mostrar_tablero()

    def realizar_accion(self, nueva_fila: int, nueva_columna: int):
        """
        Imponemos una serie de condiciones sobre lo que ocurre si el coronel william cae en alguna de las casillas marcadas
        y lo mostramos en la interfaz gráfica a través de un mensaje
        """
        elemento_destino = self.tablero[nueva_fila][nueva_columna]
        posicion_actual = (nueva_fila, nueva_columna)

        if posicion_actual == self.trampa_pinchos:
            messagebox.showinfo(
                "Accion", "¡Has caido en la trampa de pinchos! ¡Misión fallida!"
            )
            self.ventana.destroy()
        elif posicion_actual == self.trampa_dardos_venenosos:
            messagebox.showinfo(
                "Accion",
                "¡Has caido en la trampa de dardos venenosos! ¡Misión fallida!",
            )
            self.ventana.destroy()
        elif posicion_actual == self.trampa_fuego:
            messagebox.showinfo(
                "Accion", "¡Has caido en la trampa de fuego! ¡Misión fallida!"
            )
            self.ventana.destroy()
        elif posicion_actual == self.monstruo:
            messagebox.showinfo("Accion", "¡Te has encontrado con el monstruo!")
            respuesta = messagebox.askyesno(
                "Enfrentamiento",
                "Te has encontrado con el monstruo, ¿quieres lanzar el dardo?",
            )
            if not respuesta:
                messagebox.showinfo(
                    "Derrota", "No has logrado derrotar al monstruo, misión fallida."
                )
                self.ventana.destroy()
            else:
                adyacentes = self.calcular_adyacentes(posicion_actual)
                posibles_casillas = [posicion_actual]
                for adyacente in adyacentes:
                    if 0 <= adyacente[0] <= 5 and 0 <= adyacente[1] <= 5:
                        posibles_casillas.append(adyacente)
                tiro = input(
                    f"¿A que posición quieres tirar el dardo?: (opciones: {posibles_casillas}) "
                )
                if tiro == self.monstruo or tiro in self.calcular_adyacentes(
                    self.monstruo
                ):
                    messagebox.showinfo("Victoria", "El monstruo ha sido derrotado")
                    self.monstruo_derrotado = True
                else:
                    messagebox.showinfo(
                        "Derrota",
                        "No has logrado derrotar al monstruo, misión fallida.",
                    )
                self.ventana.destroy()
        elif posicion_actual == self.ck and self.coronel_kurt_encontrado == False:
            messagebox.showinfo("Accion", "¡Has encontrado al coronel Kurt!")
            self.coronel_kurt_encontrado = True
        elif elemento_destino == "S":
            messagebox.showinfo("Accion", "¡Has encontrado la salida!")
            if self.coronel_kurt_encontrado == True:
                self.ventana.destroy()
            else:
                messagebox.showinfo(
                    "Accion", "No puedes salir aun, debes encontrar al Coronel Kurt."
                )

        self.tablero[self.posicion_cw[0]][self.posicion_cw[1]] = " "
        self.posicion_cw = (nueva_fila, nueva_columna)
        self.tablero[nueva_fila][nueva_columna] = "J"

        self.mostrar_interfaz()

    def marcar_casilla(self, posicion: tuple, marca: str):
        """
        Marcamos las casillas adyacentes al monstruo y al precipicio en la interfaz
        """
        x, y = posicion
        self.tablero[x][y] = marca
        label = self.ventana.grid_slaves(row=x, column=y)[0]
        label.config(text=marca)

    def calcular_adyacentes(self, posicion: tuple):
        """
        Calculamos las posiciones adyacentes a la actual
        """
        adyacentes = [
            (posicion[0] - 1, posicion[1]),
            (posicion[0] + 1, posicion[1]),
            (posicion[0], posicion[1] - 1),
            (posicion[0], posicion[1] + 1),
        ]
        return adyacentes


def iniciar_juego():
    juego = Juego()


if __name__ == "__main__":
    # se puede ejecutar el juego de este fichero usando una de estas dos maneras:
    # juego = Juego()
    iniciar_juego()
