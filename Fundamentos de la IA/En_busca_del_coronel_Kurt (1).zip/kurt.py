import agente_logico as al
import agente_bayesiano as ab

print(
    """
    Agentes: 
    1. logico
    2. bayesiano
    """
)

opcion = int(input("Introduce el agente que deseas ejecutar: "))
if opcion == 1:
    print("Ejecutando el juego de lógica: ")
    al.iniciar_juego()
elif opcion == 2:
    print("Ejecutando el juego bayesiano: ")
    ab.iniciar_juego()
else:
    print("Gracias por jugar.")
