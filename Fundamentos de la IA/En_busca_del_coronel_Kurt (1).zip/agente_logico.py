import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from tkinter import simpledialog
import random


class Agente:
    def __init__(self, juego):
        """
        Definimos los atributos de la clase agente
        """
        self.juego = juego  # definimos una instancia de la clase juego

    def evaluar_percepto(self, nueva_posicion: tuple, percept: str):
        """
        Se evalua el tipo de percepto recibido y se avisa al jugador de lo que este implica.
        """
        if percept == "brisa":
            messagebox.showinfo(
                "Accion",
                "¡Hay una brisa cerca, cuidado las habitaciones adyacentes pueden tener un precipicio!",
            )
            self.tomar_decision(nueva_posicion)

        elif percept == "olor":
            messagebox.showinfo(
                "Accion",
                "¡Hay una peste cerca, cuidado el monstruo puede hayarse en las habitaciones adyacentes!",
            )
            self.tomar_decision(nueva_posicion)

        elif percept == "luz brillante":
            messagebox.showinfo(
                "Accion",
                "Se percibe una luz brillante cerca, la salida debe estar en una de las habitaciones contiguas.",
            )

    def realizar_inferencia(self, l: int, percept: str):
        """
        Proceso de inferencia del agente
        """

        if l == 1 and percept == "olor":
            self.juego.monstruo_encontrado = True
            lista_posiciones = list(
                self.juego.trampas_monstruo.copy()
            )  # lo pasamos a una lista para poder modificarlo
            posicion_monstruo = lista_posiciones[0]
            self.juego.marcar_casilla(posicion_monstruo, "M!")

        if l == 1 and percept == "brisa":
            self.juego.precipicio_encontrado = True
            lista_posiciones = list(self.juego.trampas_precipicio.copy())
            posicion_precipicio = lista_posiciones[0]
            self.juego.marcar_casilla(posicion_precipicio, "P!")

    def tomar_decision(self, nueva_posicion: tuple):
        """
        Dada la posición actual del jugador, en caso de que halla recibido un percepto negativo, se le indican sus posibles movimientos.
        Estos, junto a la posición donde se ha percibido el percepto, son añadidos a la base de conocimiento del agente.
        """

        adyacentes = self.juego.calcular_adyacentes(nueva_posicion)
        posibles_acciones = (
            []
        )  # lista de tuplas con la posición actual y las acciones posibles

        for i in range(len(adyacentes)):
            if adyacentes[i] in self.juego.posiciones_seguras:
                if i == 0:
                    accion = "Mover arriba"
                if i == 1:
                    accion = "Mover abajo"
                if i == 2:
                    accion = "Mover izquierda"
                if i == 3:
                    accion = "Mover derecha"

                posibles_acciones.append((str(nueva_posicion), accion))

        self.juego.base_conocimiento(posibles_acciones)


class Juego:
    def __init__(self):
        """
        Definimos los atributos de la clase Juego
        """
        self.ventana = tk.Tk()
        self.ventana.title("Encontrar al coronel Kurt")
        self.ventana.geometry("400x400")

        self.tablero = self.inicializar_tablero()
        self.posicion_cw = (0, 0)
        self.monstruo_derrotado = False
        self.monstruo_encontrado = False
        self.precipicio_encontrado = False
        self.coronel_kurt_encontrado = False
        self.posiciones_seguras = set()
        self.posiciones_peligrosas = set()
        self.trampas_monstruo = set()
        self.trampas_precipicio = set()
        self.posiciones_seguras.add((0, 0))

        self.inicializar_elementos()

        self.cuadros = []
        for i in range(6):
            fila = []
            for j in range(6):
                celda = tk.Label(
                    self.ventana, text="", width=10, height=5, relief="sunken"
                )
                celda.grid(row=i, column=j)
                fila.append(celda)
            self.cuadros.append(fila)

        self.mostrar_tablero()

        self.ventana.bind("<Up>", self.mover_arriba)
        self.ventana.bind("<Down>", self.mover_abajo)
        self.ventana.bind("<Right>", self.mover_derecha)
        self.ventana.bind("<Left>", self.mover_izquierda)

        self.ventana.mainloop()

    def inicializar_tablero(self):
        """
        Creamos el tablero inicialmente vacio y de tamaño 6x6
        """
        return [[" " for _ in range(6)] for _ in range(6)]

    def colocar_elementos(self, elemento):
        """
        Colocamos los elementos en sus posiciones asignadas
        """
        fila, columna = random.randint(0, 5), random.randint(0, 5)
        while (
            self.tablero[fila][columna] != " "
            or (fila, columna) == self.monstruo
            or (fila, columna) == self.precipicio
            or (fila, columna) == self.ck
            or (fila, columna) == self.posicion_cw
        ):
            fila, columna = random.randint(0, 5), random.randint(0, 5)
        self.tablero[fila][columna] = elemento
        return fila, columna

    def inicializar_elementos(self):
        """
        Definimos posiciones aleatorias para los elementos en el tablero.
        Además restringimos que el coronel Kurt no esté en la misma sala que el precipicio, y que el precipicio y el monstruo tampoco
        estén en la misma sala.
        También dejamos definida que la posición inicial del coronel Willard es siempre la (0,0).
        """
        self.poisicion_cw = (0, 0)
        self.monstruo = (random.randint(0, 5), random.randint(0, 5))
        while self.monstruo == self.posicion_cw:
            self.monstruo = (random.randint(0, 5), random.randint(0, 5))

        self.precipicio = (random.randint(0, 5), random.randint(0, 5))
        while self.precipicio == self.monstruo or self.precipicio == self.posicion_cw:
            self.precipicio = (random.randint(0, 5), random.randint(0, 5))

        self.ck = (random.randint(0, 5), random.randint(0, 5))
        while self.ck == self.precipicio or self.ck == self.posicion_cw:
            self.ck = (random.randint(0, 5), random.randint(0, 5))

        self.salida = self.colocar_elementos("S")

    def mostrar_tablero(self):
        """
        Mostramos el tablero en la terminal de python
        """
        colors = {
            " ": "white",
            "S": "green",
        }  # asignación de colores a los elementos que aparecen en el tablero

        for i in range(6):
            for j in range(6):
                elemento = self.tablero[i][j]
                color = colors.get(elemento, "white")
                self.cuadros[i][j].config(bg=color)

    def mostrar_interfaz(self):
        """
        Mostramos la interfaz del tablero
        """

        for i in range(6):
            for j in range(6):
                label = tk.Label(
                    self.ventana,
                    text=self.tablero[i][j],
                    width=5,
                    height=3,
                    relief="solid",
                )
                label.grid(row=i, column=j)

        cw_label = tk.Label(self.ventana, text="CW", font=("Arial", 12, "bold"))
        cw_label.grid(row=self.poisicion_cw[0], column=self.poisicion_cw[1])

        self.mostrar_tabla()

    def mostrar_tabla(self):
        """
        Mostramos una tabla adjunta a la interfaz donde se muestran las coordenadas de las posiciones peligrosas, es decir,
        donde pueden encontrarse el monstruo y el precipicio, y las posiciones seguras por donde el Coronel W puede desplazarse
        sin miedo a ser derrotado.
        """
        frame = ttk.Frame(self.ventana)
        frame.grid(row=0, column=6, rowspan=3, columnspan=3)

        tree = ttk.Treeview(
            frame,
            columns=("Posiciones Seguras", "Posiciones Peligrosas"),
            show="headings",
            height=5,
        )
        tree.heading("Posiciones Seguras", text="Posiciones Seguras")
        tree.heading("Posiciones Peligrosas", text="Posiciones Peligrosas")

        for posicion in self.posiciones_seguras:
            tree.insert("", "end", values=(posicion, ""))

        for posicion in self.posiciones_peligrosas:
            tree.insert("", "end", values=("", posicion))

        tree.pack()

    def base_conocimiento(self, posibles_acciones: list):
        """
        Creamos una base de conocimiento donde almacenamos los movimientos posibles a realizar en caso de encontrarnos en alguna celda
        adyacente a una con un posible peligro.
        Además nos ayudará a poder concluir a lo largo del recorrido en qué celdas se hayan el monstruo y el precipicio.
        """
        frame = ttk.Frame(self.ventana)
        frame.grid(row=5, column=6, rowspan=3, columnspan=3)

        tree = ttk.Treeview(
            frame,
            columns=("Posicion", "Accion"),
            show="headings",
            height=5,
        )
        tree.heading("Posicion", text="Posicion Actual")
        tree.heading("Accion", text="Acciones posibles")

        for accion in posibles_acciones:
            tree.insert("", "end", values=accion)

        tree.pack()

    def mover_arriba(self, event):
        """
        Definimos la acción de moverse arriba que se correspondera con la flecha del ordenador que apunta arriba.
        """
        nueva_fila = max(0, self.posicion_cw[0] - 1)
        self.verificar_percept((nueva_fila, self.posicion_cw[1]))
        self.realizar_accion(nueva_fila, self.posicion_cw[1])
        self.actualizar_posicion((nueva_fila, self.posicion_cw[1]))

    def mover_abajo(self, event):
        """
        Definimos la acción de moverse abajo que se correspondera con la flecha del ordenador que apunta abajo
        """
        nueva_fila = min(5, self.posicion_cw[0] + 1)
        self.verificar_percept((nueva_fila, self.posicion_cw[1]))
        self.realizar_accion(nueva_fila, self.posicion_cw[1])
        self.actualizar_posicion((nueva_fila, self.posicion_cw[1]))

    def mover_derecha(self, event):
        """
        Definimos la acción de desplazarse a la derecha que se correspondera con la flecha del ordenador que apunta a la derecha
        """
        nueva_columna = min(5, self.posicion_cw[1] + 1)
        self.verificar_percept((self.posicion_cw[0], nueva_columna))
        self.realizar_accion(self.posicion_cw[0], nueva_columna)
        self.actualizar_posicion((self.posicion_cw[0], nueva_columna))

    def mover_izquierda(self, event):
        """
        Definimos la acción de desplazarse a la izquierda que se correspondera con la flecha del ordenador que apunta a la izquierda
        """
        nueva_columna = max(0, self.posicion_cw[1] - 1)
        self.verificar_percept((self.posicion_cw[0], nueva_columna))
        self.realizar_accion(self.posicion_cw[0], nueva_columna)
        self.actualizar_posicion((self.posicion_cw[0], nueva_columna))

    def verificar_percept(self, nueva_posicion: tuple):
        """
        Estudiamos las posiciones adyacentes a donde está CW, si en alguna de estas está el monstruo o hay un precipicio,
        se recibirá dicho precepto y se añadirán las posiciones adjuntas a la posición actual al conjunto de peligrosas,
        en caso de no percibir nada, se añadirán al conjunto de seguras.
        La posición acutal es añadida al conjunto de seguras.
        """
        self.posiciones_seguras.add(nueva_posicion)

        adyacentes = [
            (nueva_posicion[0] - 1, nueva_posicion[1]),
            (nueva_posicion[0] + 1, nueva_posicion[1]),
            (nueva_posicion[0], nueva_posicion[1] - 1),
            (nueva_posicion[0], nueva_posicion[1] + 1),
        ]  # calculo de las posiciones adyacentes a la actual.

        agente = Agente(self)  # instancia de un agente

        for posicion in adyacentes:
            fila, columna = posicion

            if (
                0 <= fila <= 5 and 0 <= columna <= 5
            ):  # unicamente consideramos adyacentes admisibles las que se encuentren dentro de los límites del tablero
                elemento = self.tablero[fila][columna]

                if elemento != "S" and posicion != self.ck:
                    if (
                        posicion == self.monstruo and self.monstruo_encontrado == False
                    ):  # si es el monstruo y no ha sido ya derrotado o se ha derivado ya su posición
                        percept = "olor"

                        for adyacente in adyacentes:
                            if (
                                adyacente not in self.posiciones_seguras
                                and adyacente not in self.trampas_precipicio
                                and adyacente != self.salida
                                and 0 <= adyacente[0] <= 5
                                and 0 <= adyacente[1] <= 5
                            ):
                                self.posiciones_peligrosas.add(adyacente)
                                self.trampas_monstruo.add(adyacente)
                                self.marcar_casilla(adyacente, "M?")
                                self.marcar_casilla(nueva_posicion, "CWo")

                        for pos in self.trampas_monstruo.copy():
                            if pos not in adyacentes:
                                self.marcar_casilla(pos, "")
                                self.trampas_monstruo.remove(pos)
                                self.posiciones_peligrosas.remove(pos)
                                self.posiciones_seguras.add(pos)

                        agente.evaluar_percepto(
                            nueva_posicion, percept
                        )  # mandamos el percepto recibido al agente para que él derive lo que eso implica y pueda hacer sus deducciones

                        agente.realizar_inferencia(
                            len(self.trampas_monstruo.copy()), percept
                        )

                    elif (
                        posicion == self.precipicio
                        and self.precipicio_encontrado == False
                    ):
                        percept = "brisa"

                        for adyacente in adyacentes:
                            if (
                                adyacente not in self.posiciones_seguras
                                and adyacente not in self.trampas_monstruo
                                and adyacente != self.salida
                                and 0 <= adyacente[0] <= 5
                                and 0 <= adyacente[1] <= 5
                            ):
                                self.posiciones_peligrosas.add(adyacente)
                                self.trampas_precipicio.add(adyacente)
                                self.marcar_casilla(adyacente, "P?")
                                self.marcar_casilla(nueva_posicion, "CWb")

                        for pos in self.trampas_precipicio.copy():
                            if pos not in adyacentes:
                                self.marcar_casilla(pos, "")
                                self.trampas_precipicio.remove(pos)
                                self.posiciones_peligrosas.remove(pos)
                                self.posiciones_seguras.add(pos)

                        agente.evaluar_percepto(nueva_posicion, percept)

                        agente.realizar_inferencia(
                            len(self.trampas_precipicio.copy()),
                            percept,
                        )
                    else:
                        if posicion != self.monstruo and posicion != self.precipicio:
                            self.posiciones_seguras.add(posicion)

                if elemento == "S":
                    percept = "luz brillante"
                    agente.evaluar_percepto(posicion, percept)
                    self.posiciones_seguras.add(posicion)

    def actualizar_posicion(self, nueva_posicion: tuple):
        """
        Actualizamos la posición del Coronel W según se desplaza por el mapa
        """
        self.posicion_cw = nueva_posicion
        self.mostrar_tablero()

    def realizar_accion(self, nueva_fila: int, nueva_columna: int):
        """
        Imponemos una serie de condiciones sobre lo que ocurre si el coronel william cae en alguna de las casillas marcadas
        y lo mostramos en la interfaz gráfica a través de un mensaje
        """
        elemento_destino = self.tablero[nueva_fila][nueva_columna]
        posicion_actual = (nueva_fila, nueva_columna)

        if posicion_actual == self.precipicio:
            messagebox.showinfo(
                "Accion", "¡Has caido en el precipicio! ¡Misión fallida!"
            )
            self.ventana.destroy()
        elif posicion_actual == self.monstruo and self.monstruo_derrotado == False:
            messagebox.showinfo("Accion", "¡Te has encontrado con el monstruo!")
            respuesta = messagebox.askyesno(
                "Enfrentamiento",
                "Te has encontrado con el monstruo, ¿quieres lanzar la granada?",
            )
            if not respuesta:
                messagebox.showinfo(
                    "Derrota", "No has logrado derrotar al monstruo, misión fallida."
                )
                self.ventana.destroy()
            else:
                adyacentes = self.calcular_adyacentes(posicion_actual)
                posibles_casillas = [posicion_actual]
                for adyacente in adyacentes:
                    if 0 <= adyacente[0] <= 5 and 0 <= adyacente[1] <= 5:
                        posibles_casillas.append(adyacente)
                tiro = input(
                    f"¿A que posición quieres tirar la granada?: (opciones: {posibles_casillas}) "
                )
                if tiro == self.monstruo or tiro in self.calcular_adyacentes(
                    self.monstruo
                ):
                    messagebox.showinfo("Victoria", "El monstruo ha sido derrotado")
                    self.monstruo_derrotado = True
                else:
                    messagebox.showinfo(
                        "Derrota",
                        "No has logrado derrotar al monstruo, misión fallida.",
                    )
                    self.ventana.destroy()
        elif posicion_actual == self.ck and self.coronel_kurt_encontrado == False:
            messagebox.showinfo("Accion", "¡Has encontrado al coronel Kurt!")
            self.coronel_kurt_encontrado = True
        elif elemento_destino == "S":
            messagebox.showinfo("Accion", "¡Has encontrado la salida!")
            if self.coronel_kurt_encontrado == True:
                self.ventana.destroy()
            else:
                messagebox.showinfo(
                    "Accion", "No puedes salir aun, debes encontrar al Coronel Kurt."
                )

        self.tablero[self.poisicion_cw[0]][self.poisicion_cw[1]] = " "
        self.poisicion_cw = (nueva_fila, nueva_columna)
        self.tablero[nueva_fila][nueva_columna] = "J"

        self.mostrar_interfaz()

    def marcar_casilla(self, posicion: tuple, marca: str):
        """
        Marcamos las casillas adyacentes al monstruo y al precipicio en la interfaz
        """
        x, y = posicion
        self.tablero[x][y] = marca
        label = self.ventana.grid_slaves(row=x, column=y)[0]
        label.config(text=marca)

    def calcular_adyacentes(self, posicion: tuple):
        """
        Función que calcula las posiciones adyacentes a la actual
        """
        adyacentes = [
            (posicion[0] - 1, posicion[1]),
            (posicion[0] + 1, posicion[1]),
            (posicion[0], posicion[1] - 1),
            (posicion[0], posicion[1] + 1),
        ]
        return adyacentes


def iniciar_juego():
    juego = Juego()


if __name__ == "__main__":
    # se puede ejecutar el juego de este fichero usando una de estas dos maneras:
    # juego = Juego()
    iniciar_juego()
