import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split


def limpiar_df(df_str: str) -> tuple:
    df = pd.read_csv(f"{df_str}", sep=";")

    # Eliminamos los datos nulos de la columna output
    df = df.dropna(subset=["RiskPerformance"])
    # Eliminar las filas que contienen los valores -9 en cualquier columna
    df = df[~df.isin([-9]).any(axis=1)]

    # Pasamos ahora a hacer el train test split

    # Paso 1: Shuffle the data (check out the .sample() method in pandas)
    df = df.sample(frac=1)

    from sklearn.impute import KNNImputer

    # Crear el imputador KNN con, por ejemplo, 2 vecinos
    imputer = KNNImputer(weights="uniform")

    df = pd.DataFrame(imputer.fit_transform(df), columns=df.columns)


def train_test_split(X, y):
    # Paso 3 dividir el conjunto
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

    return X_train, X_test, y_train, y_test


def standarize_X_train(X_train) -> tuple:

    # Estandarización de los datos del train y el test con la media y varianza del train
    for variable in X_train:
        mean = X_train[f"{variable}"].mean()
        var = X_train[f"{variable}"].var()
        std = X_train[f"{variable}"].std()
        standarization_var = lambda value: (value - mean) / std
        X_train[f"{variable}"] = X_train[f"{variable}"].apply(standarization_var)

    return X_train


def standarize_X_test(X_train, X_test) -> tuple:

    # Estandarización de los datos del train y el test con la media y varianza del train
    for variable in X_train:
        mean = X_train[f"{variable}"].mean()
        var = X_train[f"{variable}"].var()
        std = X_train[f"{variable}"].std()
        standarization_var = lambda value: (value - mean) / std
        X_test[f"{variable}"] = X_test[f"{variable}"].apply(standarization_var)

    return X_test


def matriz_cov(X_train):
    correlation_matrix = X_train.corr()
    plt.figure(figsize=(15, 10))
    sns.heatmap(correlation_matrix, annot=True, cmap="coolwarm")
    plt.title("Heatmap de Correlación entre inputs y outputs")
    plt.show()


def distribucion_train(X_train, inputs):
    for var in inputs:
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        # Histograma para el conjunto de train
        sns.histplot(X_train[var], ax=axes[0], color=sns.color_palette("pastel")[7])
        axes[0].set_title(f"Histograma de {var} - Training Set")

        # Boxplot para el conjunto de train
        sns.boxplot(y=X_train[var], ax=axes[1], color=sns.color_palette("pastel")[1])
        axes[1].set_title(f"Boxplot de {var} - Training Set")
