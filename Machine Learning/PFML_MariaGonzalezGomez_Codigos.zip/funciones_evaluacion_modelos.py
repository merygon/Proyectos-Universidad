import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.model_selection import cross_val_score
from utils import classification_report
from sklearn.metrics import accuracy_score

"""
Este es un fichero python que contiene las númerosas funciones que se han usado tanto en el apartado 2 de Supervised Learning como en el 3 de Unsupervised Learning.
Entre ellas encontramos:
    1. CV_MODEL: Una función que devuleve para cada modelo el valor óptimo del parametro que se desea obtener por validación cruzada.
"""


# vamos a definir una función tipo para poder realizar validación cruzada en cada modelo
def cv_model(model, X, y, param_values: range, parametro: str, cv=5):
    mean_scores = []
    std_scores = []
    for value in param_values:
        model.set_params(**{parametro: value})
        scores = cross_val_score(model, X, y, cv=cv)
        mean_scores.append(np.mean(scores))
        std_scores.append(np.std(scores))

    highest_score = max(mean_scores)
    optimal_value = np.where(mean_scores == highest_score)
    optimal_value = optimal_value[0][0] + param_values[0]

    return mean_scores, std_scores, optimal_value, highest_score
