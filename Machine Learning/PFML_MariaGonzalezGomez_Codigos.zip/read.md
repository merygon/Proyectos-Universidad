Para ejecutar los resultados mostrados en la memoria se pueden seguir 2 rutas:
1. Ejecutar unicamente el fichero parte1.ipynb donde está todo el código junto 
2. Ejecutar el fichero parte2.ipynb para estudiar los algoritmos de clasificación de la parte 2, después el fichero part3.ipynb para los algoritmos de clustering y PCA de la parte 3.

Los ficheros .py contienen las funciones de limpieza de dataset, train_test_split y CV.